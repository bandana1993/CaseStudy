﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_SCHOOL
{
    

    public class chairperson
    {
        public int instructor
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }

    
    public abstract class School
    {
        public static int a = 1;
        int id = a;
        public int StudentId
        { get { return id; } }

        public string StudentName
        { get; set; }

        public string Department
        { get; set; }

        public string CourseName
        { get; set; }
        public int CourseId
        { get; set; }

        public int number
        { get; set; }
        public abstract void addStudent();
        public abstract void removeStudent();
        public abstract void getStudent();
        public abstract void getAllStudents();
        public abstract void addDepartment();
        public abstract void removeDepartmentt();
        public abstract void getDepartment();
        public abstract void getAllDepartments();
        public abstract void displaystudentsall();
        public abstract void displaydepartmentsall();

    }
  


    class FinanceAccount : School
    {
        public FinanceAccount()
        {

        }
        public FinanceAccount(string StudName)
        {
            StudentName = StudName;
        }

        public override void addStudent()
        {
            a += 1;
            Console.Write("Enter the Student Name:");
            StudentName = Console.ReadLine();
            Console.WriteLine("Student ID: " + StudentId);
            Console.WriteLine("Department: " + Department);
            Console.WriteLine("CourseName:" + CourseName);
            Console.WriteLine("CourseId:" + CourseId);
        }
        public override void displaystudentsall()
        {
            Console.WriteLine("Details of Student:");

            Console.WriteLine("StudId  StudName Dept CourseId  CourseName   ");

        }

        public override void getStudent()
        {
            Console.WriteLine("{0}  {1}  {2}  {3}  {4}  ", StudentId, StudentName, Department, CourseId, CourseName);
        }
        public override void displaydepartmentsall()
        {
            Console.WriteLine("Details of Dept");
            Console.WriteLine("Department   StudId   StudName  CourseId  CourseName ");

        }

        public override void getDepartment()
        {
            Console.WriteLine("    {0}    {1}  {2}  {3}   {4} ", Department, StudentId, StudentName, CourseId, CourseName);
        }
        public override void getAllDepartments()
        {
            throw new NotImplementedException();
        }
        public override void addDepartment()
        {
            
        }
        public override void getAllStudents()
        {
            throw new NotImplementedException();
        }
        public override void removeDepartmentt()
        {
            throw new NotImplementedException();
        }
        public override void removeStudent()
        {
            throw new NotImplementedException();
        }

       ~ FinanceAccount()
        {

        }
    }

class  NotImplementedException: Exception
    {

    }
    

    class SalesManagement : School
    {
        public SalesManagement()
        {
        }
        public SalesManagement(string Studname)
        {
            StudentName = Studname;
        }

        public override void addStudent()
        {
            a += 1;
            Console.Write("Enter the Student Name:");
            StudentName = Console.ReadLine();
            Console.WriteLine("Student ID: " + StudentId);
            Console.WriteLine("Department: " + Department);
            Console.WriteLine("CourseName:" + CourseName);
            Console.WriteLine("CourseId:" + CourseId);
        }

        public override void getAllDepartments()
        {
            throw new NotImplementedException();
        }
        public override void addDepartment()
        {
            throw new NotImplementedException();
        }
        public override void getAllStudents()
        {
            throw new NotImplementedException();
        }
        public override void removeDepartmentt()
        {
            throw new NotImplementedException();
        }
        public override void removeStudent()
        {
            throw new NotImplementedException();
        }
        public override void displaydepartmentsall()
        {
            throw new NotImplementedException();
        }
        public override void displaystudentsall()
        {

        }
        public override void getDepartment()
        {
            throw new NotImplementedException();
        }
        public override void getStudent()
        {
            throw new NotImplementedException();
        }
        ~SalesManagement()
        {

        }
    }


    class Program
    {
        public static int i = 0, size = 0;
        public static List<School> l = new List<School>();
        public static int check(List<School> l)
        {
            Console.Write("Enter the StudentId: ");
            Int64 a = Convert.ToInt64(Console.ReadLine());

            for (i = 0; i < size; i++)
            {
                if (a == l[i].StudentId)
                {
                    return i;
                }
            }

            return 2;
        }
        static void Main(string[] args)
        {
            string ans;
            int i = 0;
            while (true)
            {
                do
                {

                
                Console.WriteLine("1.StudentAdmission \n 2.RemoveStudent \n 3.Display a Student \n 4.DisplayAllStudent \n 5.DepartmentAddition \n 6.Remove Department \n 7.Show a Department \n 8.ShowAllDept \n9.Exit");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        try
                        {
                            Console.WriteLine("Enter which Department \n1.Finance and Account \n2.Sales and Management");
                            ch = Convert.ToInt32(Console.ReadLine());
                                if (ch == 1)
                                {
                                    Console.WriteLine("Enter which Department \n1.Accounting System \n2.Finance System \n 3.Corporate Finance System \n4.Financial \n5.Exit");
                                    {
                                        for (int size = 0; size < 15; size++)
                                        {


                                            ch = Convert.ToInt32(Console.ReadLine());
                                            if (ch == 1)
                                            {
                                                l.Add(new FinanceAccount());
                                                l[size].Department = "Finance and Account";
                                                l[size].CourseName = "Accounting System";
                                                l[size].CourseId = 101;
                                                l[size].addStudent();
                                                size++;
                                            }
                                            else if (ch == 2)
                                            {
                                                l.Add(new FinanceAccount());
                                                l[size].Department = "Finance and Account";
                                                l[size].CourseName = "Finance System";
                                                l[size].CourseId = 102;
                                                l[size].addStudent();
                                                size++;
                                            }
                                            else if (ch == 3)
                                            {
                                                l.Add(new FinanceAccount());
                                                l[size].Department = "Finance and Account";
                                                l[size].CourseName = "Corporate Finance System";
                                                l[size].CourseId = 103;
                                                l[size].addStudent();
                                                size++;
                                            }
                                            else if (ch == 4)
                                            {
                                                l.Add(new FinanceAccount());
                                                l[size].Department = "Finance and Account";
                                                l[size].CourseName = "Financial Administration";
                                                l[size].CourseId = 104;
                                                l[size].addStudent();
                                                size++;
                                            }
                                            else Console.Write("Invalid");
                                        }
                                    }

                                }
                                else if (ch == 2)
                                {
                                    for (int size = 0; size < 12; size++)
                                    {


                                        Console.WriteLine("Enter which Department \n1.Sales \n2.Economy \n 3.Marketing \n4.Merchandise \n5.Management \n6.Exit");
                                        {
                                            ch = Convert.ToInt32(Console.ReadLine());
                                            if (ch == 1)
                                            {

                                                l.Add(new SalesManagement());
                                                l[size].Department = "Sales and Management";
                                                l[size].CourseName = "Sales";
                                                l[size].CourseId = 201;
                                                l[size].addStudent();
                                                size++;
                                            }
                                            else if (ch == 2)
                                            {
                                                l.Add(new SalesManagement());
                                                l[size].Department = "Sales and Management";
                                                l[size].CourseName = "Economy";
                                                l[size].CourseId = 202;
                                                l[size].addStudent();
                                                size++;
                                            }
                                            else if (ch == 3)
                                            {
                                                l.Add(new SalesManagement());

                                                l[size].Department = "Sales and Management";
                                                l[size].CourseName = "Marketing";
                                                l[size].CourseId = 203;
                                                l[size].addStudent();
                                                size++;
                                            }
                                            else if (ch == 4)
                                            {
                                                l.Add(new SalesManagement());

                                                l[size].Department = "Sales and Management";
                                                l[size].CourseName = "Merchandise";
                                                l[size].CourseId = 204;
                                                l[size].addStudent();
                                                size++;
                                            }
                                            else if (ch == 5)
                                            {
                                                l.Add(new SalesManagement());

                                                l[size].Department = "Sales and Management";
                                                l[size].CourseName = "Management";
                                                l[size].CourseId = 205;
                                                l[size].addStudent();
                                                size++;
                                            }
                                            else Console.Write("Invalid");
                                        }
                                    }
                                }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                            Console.WriteLine("Please Try Again");
                        }
                        break;
                    case 2:
                        i = check(l);
                        if (i == 2)
                        {
                            Console.WriteLine("Id not found");
                            break;
                        }
                        l.Remove(l[i]);
                        size--;
                        Console.WriteLine("Successfully Removed");
                        break;
                    case 3:
                        i = check(l);
                        if (i == 2)
                        {
                            Console.WriteLine("Id not found");
                            break;
                        }
                        l[0].displaystudentsall();
                        l[i].getStudent();
                        break;
                    case 4:
                        l[0].displaystudentsall();
                        for (i = 0; i < size; i++)
                            l[i].getStudent();
                        break;
                    case 5:
                        Console.WriteLine("Enter which Department \n1.Finance and Account \n2.Sales and Management");
                        int c = Convert.ToInt16(Console.ReadLine());
                        if (c == 1)
                        {

                            l.Add(new FinanceAccount());
                            l[size].Department = "Finance and Account";
                            l[size].addDepartment();
                            size++;
                        }
                        else if (c == 2)
                        {

                            l.Add(new SalesManagement());
                            l[size].Department = "Sales and Management";
                            l[size].addDepartment();
                            size++;
                        }
                        else
                            Console.Write("Invalid");
                        break;
                    case 6:
                        i = check(l);
                        if (i == 2)
                        {
                            Console.WriteLine("Dept not found");
                            break;
                        }
                        l.Remove(l[i]);
                        size--;
                        Console.WriteLine("Successfully Removed");
                        break;
                    case 7:
                        i = check(l);
                        if (i == 2)
                        {
                            Console.WriteLine("dept not found");
                            break;
                        }
                        l[0].displaydepartmentsall();
                        l[i].getDepartment();
                        break;
                    case 8:
                        l[0].displaydepartmentsall();
                        for (i = 0; i < size; i++)
                            l[i].getDepartment();
                        break;
                    case 9:
                        return;

                       
                }
                    Console.WriteLine("Do you wish to continue(yes/no)");
                      ans = Console.ReadLine();
                    Console.Clear();
                    if(ans.Equals("no"))
                    {
                        return;
                    }
                } while (ans.Equals("yes"));
                

                
            }
        }
    }
}
